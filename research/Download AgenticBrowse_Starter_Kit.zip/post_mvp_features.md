# 🌟 Post-MVP Features

- Multi-tab agentic browsing
- Site plugin marketplace
- Local LLM support
- Offline task automation
- Agentic scripting IDE in-app

---