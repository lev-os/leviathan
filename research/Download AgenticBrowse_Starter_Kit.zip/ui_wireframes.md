# 🎨 UI Wireframes (Text-based)

┌───────────────────────────┐
│ AgenticBrowse             │
│───────────────────────────│
│ [ INPUT: URL ] [ GO ]     │
│───────────────────────────│
│ [ WebView iframe here ]   │
│                           │
│───────────────────────────│
│ JS Injection: [_________] │
│ [ Inject JS ] [ Run Agent ]│
└───────────────────────────┘

---